#!/bin/bash
echo dev