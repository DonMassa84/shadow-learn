# ShadowLearn v4
Fullstack adaptive learning engine.